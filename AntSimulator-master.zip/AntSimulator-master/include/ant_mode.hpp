#pragma once
#include <cstdint>


enum class Mode : uint32_t
{
	ToHome = 0,
	ToFood = 1,
};