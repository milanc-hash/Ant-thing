#pragma once
#include <SFML/System/Vector2.hpp>


struct Wall
{
	sf::Vector2f position;
};